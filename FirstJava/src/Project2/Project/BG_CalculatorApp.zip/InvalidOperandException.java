package Project2.Project;

//Authors: Jaden Bigos, Brendan Goddard
//Date: 8/8/2023

public class InvalidOperandException extends RuntimeException {
    public InvalidOperandException(String message) {
        super(message);
    }
}
